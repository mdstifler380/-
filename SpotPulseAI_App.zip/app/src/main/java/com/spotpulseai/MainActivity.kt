package com.spotpulseai
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import dagger.hilt.android.AndroidEntryPoint
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.spotpulseai.ui.SetupScreen
import com.spotpulseai.ui.ModeScreen
import com.spotpulseai.ui.DashboardScreen
import com.spotpulseai.ui.MainViewModel

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface {
                    val navController = rememberNavController()
                    val viewModel: MainViewModel = hiltViewModel()
                    
                    NavHost(navController = navController, startDestination = "setup") {
                        composable("setup") { SetupScreen(navController, viewModel) }
                        composable("mode_selection") { ModeScreen(navController, viewModel) }
                        composable("dashboard") { DashboardScreen(navController, viewModel) }
                    }
                }
            }
        }
    }
}
