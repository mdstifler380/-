package com.spotpulseai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.Surface
import dagger.hilt.android.AndroidEntryPoint
import androidx.hilt.navigation.compose.hiltViewModel
import com.spotpulseai.ui.SpotPulseTheme
import com.spotpulseai.ui.MainAppContainer
import com.spotpulseai.ui.MainViewModel

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            SpotPulseTheme {
                Surface {
                    val viewModel: MainViewModel = hiltViewModel()
                    MainAppContainer(viewModel = viewModel)
                }
            }
        }
    }
}
