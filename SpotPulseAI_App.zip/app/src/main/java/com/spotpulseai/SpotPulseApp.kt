package com.spotpulseai
import android.app.Application
import dagger.hilt.android.HiltAndroidApp
@HiltAndroidApp
class SpotPulseApp : Application()
