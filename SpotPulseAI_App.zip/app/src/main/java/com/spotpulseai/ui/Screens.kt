package com.spotpulseai.ui
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.spotpulseai.domain.EngineState

@Composable
fun SetupScreen(navController: NavController, viewModel: MainViewModel) {
    var apiKey by remember { mutableStateOf("") }
    var apiSecret by remember { mutableStateOf("") }
    
    Column(modifier = Modifier.padding(24.dp).fillMaxSize(), verticalArrangement = Arrangement.Center) {
        Text("Binance API Setup", style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(16.dp))
        OutlinedTextField(value = apiKey, onValueChange = { apiKey = it }, label = { Text("API Key") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = apiSecret, onValueChange = { apiSecret = it }, label = { Text("Secret Key") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(24.dp))
        Button(onClick = { 
            viewModel.setApiKeys(apiKey, apiSecret)
            navController.navigate("mode_selection")
        }, modifier = Modifier.fillMaxWidth()) { Text("CONNECT") }
    }
}

@Composable
fun ModeScreen(navController: NavController, viewModel: MainViewModel) {
    Column(modifier = Modifier.padding(24.dp).fillMaxSize(), verticalArrangement = Arrangement.Center) {
        Text("Select Trading Mode", style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(8.dp))
        Text("Both modes use your connected API for real-time market data.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(32.dp))
        
        Button(onClick = { 
            viewModel.setTradingMode(isLive = false)
            navController.navigate("dashboard")
        }, modifier = Modifier.fillMaxWidth().height(60.dp)) { Text("PAPER MODE (Virtual $20)") }
        
        Spacer(Modifier.height(16.dp))
        
        Button(onClick = { 
            viewModel.setTradingMode(isLive = true)
            navController.navigate("dashboard")
        }, modifier = Modifier.fillMaxWidth().height(60.dp), colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)) { 
            Text("LIVE MODE (Real Funds)") 
        }
    }
}

@Composable
fun DashboardScreen(navController: NavController, viewModel: MainViewModel) {
    val engineState by viewModel.engineState.collectAsState()
    val walletBalance by viewModel.walletBalance.collectAsState()
    val isLive by viewModel.isLiveMode.collectAsState()

    Column(modifier = Modifier.padding(16.dp).fillMaxSize()) {
        Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
            Text(text = "SpotPulseAI", style = MaterialTheme.typography.headlineMedium)
            Badge(containerColor = if(isLive) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary) {
                Text(if(isLive) "LIVE" else "PAPER", modifier = Modifier.padding(4.dp))
            }
        }
        Spacer(modifier = Modifier.height(16.dp))
        
        Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(text = "FDUSD Balance: $walletBalance", style = MaterialTheme.typography.titleLarge)
                Text(text = if(isLive) "Real Binance Wallet" else "Virtual Paper Wallet", style = MaterialTheme.typography.bodySmall)
            }
        }
        Spacer(modifier = Modifier.height(24.dp))
        Button(
            onClick = { viewModel.toggleEngine() },
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = if(engineState == EngineState.Running) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary)
        ) {
            Text(if (engineState == EngineState.Running) "STOP ENGINE" else "START ENGINE")
        }
    }
}
