package com.spotpulseai.ui
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.spotpulseai.domain.EngineState

@Composable
fun SetupScreen(navController: NavController, viewModel: MainViewModel) {
    var apiKey by remember { mutableStateOf("") }
    var apiSecret by remember { mutableStateOf("") }
    
    Column(
        modifier = Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).padding(24.dp), 
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("SpotPulseAI", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
        Spacer(Modifier.height(8.dp))
        Text("Binance API Setup", style = MaterialTheme.typography.titleMedium, color = Color.LightGray)
        Spacer(Modifier.height(32.dp))
        
        OutlinedTextField(
            value = apiKey, onValueChange = { apiKey = it }, 
            label = { Text("API Key") }, 
            modifier = Modifier.fillMaxWidth(),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = MaterialTheme.colorScheme.primary,
                unfocusedBorderColor = Color.DarkGray
            )
        )
        Spacer(Modifier.height(16.dp))
        OutlinedTextField(
            value = apiSecret, onValueChange = { apiSecret = it }, 
            label = { Text("Secret Key") }, 
            modifier = Modifier.fillMaxWidth(),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = MaterialTheme.colorScheme.primary,
                unfocusedBorderColor = Color.DarkGray
            )
        )
        Spacer(Modifier.height(32.dp))
        Button(
            onClick = { 
                viewModel.setApiKeys(apiKey, apiSecret)
                navController.navigate("mode_selection")
            }, 
            modifier = Modifier.fillMaxWidth().height(56.dp),
            shape = RoundedCornerShape(8.dp)
        ) { Text("CONNECT WALLET", fontSize = 16.sp, fontWeight = FontWeight.Bold) }
    }
}

@Composable
fun ModeScreen(navController: NavController, viewModel: MainViewModel) {
    Column(
        modifier = Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).padding(24.dp), 
        verticalArrangement = Arrangement.Center
    ) {
        Text("Execution Mode", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text("Both modes use live WebSocket data.", style = MaterialTheme.typography.bodyMedium, color = Color.Gray)
        Spacer(Modifier.height(32.dp))
        
        Button(
            onClick = { 
                viewModel.setTradingMode(isLive = false)
                navController.navigate("dashboard")
            }, 
            modifier = Modifier.fillMaxWidth().height(64.dp),
            shape = RoundedCornerShape(8.dp)
        ) { Text("PAPER MODE (Virtual $20)", fontSize = 16.sp, fontWeight = FontWeight.Bold) }
        
        Spacer(Modifier.height(16.dp))
        
        Button(
            onClick = { 
                viewModel.setTradingMode(isLive = true)
                navController.navigate("dashboard")
            }, 
            modifier = Modifier.fillMaxWidth().height(64.dp), 
            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
            shape = RoundedCornerShape(8.dp)
        ) { Text("LIVE MODE (Real Funds)", fontSize = 16.sp, fontWeight = FontWeight.Bold) }
    }
}

@Composable
fun DashboardScreen(navController: NavController, viewModel: MainViewModel) {
    val engineState by viewModel.engineState.collectAsState()
    val walletBalance by viewModel.walletBalance.collectAsState()
    val isLive by viewModel.isLiveMode.collectAsState()

    Column(modifier = Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).padding(16.dp)) {
        Row(
            horizontalArrangement = Arrangement.SpaceBetween, 
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth().padding(top = 16.dp, bottom = 24.dp)
        ) {
            Text(text = "SpotPulseAI", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(4.dp))
                    .border(1.dp, if(isLive) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.secondary, RoundedCornerShape(4.dp))
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Text(
                    text = if(isLive) "LIVE (REAL)" else "PAPER", 
                    color = if(isLive) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.secondary,
                    fontSize = 12.sp, fontWeight = FontWeight.Bold
                )
            }
        }
        
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text(text = "WALLET SYNC", fontSize = 12.sp, color = Color.Gray, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(8.dp))
                Text(text = "$$walletBalance FDUSD", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = if(isLive) "Binance Spot Wallet" else "Virtual Balance", 
                    fontSize = 14.sp, color = Color.DarkGray
                )
            }
        }
        
        Spacer(modifier = Modifier.height(32.dp))
        
        Button(
            onClick = { viewModel.toggleEngine() },
            modifier = Modifier.fillMaxWidth().height(64.dp),
            colors = ButtonDefaults.buttonColors(containerColor = if(engineState == EngineState.Running) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.secondary),
            shape = RoundedCornerShape(8.dp)
        ) {
            Text(
                if (engineState == EngineState.Running) "STOP ENGINE" else "START ENGINE",
                fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color.White
            )
        }
    }
}
