package com.spotpulseai.ui
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject
import com.spotpulseai.domain.EngineState
import com.spotpulseai.data.SessionManager
import com.spotpulseai.data.BinanceRepository
import com.spotpulseai.domain.BotCoordinator
@HiltViewModel
class MainViewModel @Inject constructor(
    val sessionManager: SessionManager,
    private val binanceRepo: BinanceRepository,
    private val botCoordinator: BotCoordinator
) : ViewModel() {
    val engineState = botCoordinator.engineState
    private val _walletBalance = MutableStateFlow("0.00")
    val walletBalance = _walletBalance.asStateFlow()
    val isLiveMode = MutableStateFlow(false)
    fun setApiKeys(key: String, secret: String) {
        sessionManager.apiKey = key
        sessionManager.apiSecret = secret
    }
    fun setTradingMode(isLive: Boolean) {
        sessionManager.isLiveMode = isLive
        isLiveMode.value = isLive
        if (!isLive) sessionManager.paperBalance = 20.00
        updateBalanceDisplay()
    }
    private fun updateBalanceDisplay() {
        viewModelScope.launch { _walletBalance.value = String.format("%.2f", binanceRepo.syncWalletBalance()) }
    }
    fun toggleEngine() {
        if (engineState.value is EngineState.Running) botCoordinator.stopEngine() else botCoordinator.startEngine(viewModelScope)
    }
}