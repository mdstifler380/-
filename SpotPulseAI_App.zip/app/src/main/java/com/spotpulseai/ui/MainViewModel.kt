package com.spotpulseai.ui

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject
import com.spotpulseai.domain.EngineState
import com.spotpulseai.data.SessionManager
import com.spotpulseai.data.BinanceRepository
import com.spotpulseai.domain.BotCoordinator
import com.spotpulseai.service.TradingService

@HiltViewModel
class MainViewModel @Inject constructor(
    val sessionManager: SessionManager,
    private val binanceRepo: BinanceRepository,
    private val botCoordinator: BotCoordinator
) : ViewModel() {
    val engineState = botCoordinator.engineState
    val activePosition = botCoordinator.activePosition
    val liveLogs = botCoordinator.liveLogs
    val scannerStates = botCoordinator.scannerStates
    val walletBalance = botCoordinator.walletBalance
    
    val isLiveMode = MutableStateFlow(sessionManager.isLiveMode)
    val showApiKeyDialog = MutableStateFlow(false)

    fun setApiKeys(key: String, secret: String, isLive: Boolean) {
        sessionManager.apiKey = key
        sessionManager.apiSecret = secret
        sessionManager.isLiveMode = isLive
        isLiveMode.value = isLive
        showApiKeyDialog.value = false
        if (isLive) {
            viewModelScope.launch {
                binanceRepo.syncWalletBalance()
            }
        }
    }

    fun toggleEngine(context: Context? = null) {
        if (context != null) {
            if (engineState.value is EngineState.Running) {
                TradingService.stopEngine(context)
            } else {
                TradingService.startEngine(context)
            }
        } else {
            if (engineState.value is EngineState.Running) {
                botCoordinator.stopEngine()
            } else {
                botCoordinator.startEngine(viewModelScope)
            }
        }
    }
}
