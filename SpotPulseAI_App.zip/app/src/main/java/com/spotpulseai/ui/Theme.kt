package com.spotpulseai.ui

import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val DarkCyberScheme = darkColorScheme(
    background = Color(0xFF080A0E),
    surface = Color(0xFF10141D),
    surfaceVariant = Color(0xFF151B27),
    primary = Color(0xFF2463EB),
    secondary = Color(0xFF0ECB81),
    error = Color(0xFFF6465D),
    onBackground = Color.White,
    onSurface = Color.White,
    outline = Color(0xFF1E2838)
)

@Composable
fun SpotPulseTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = DarkCyberScheme,
        content = content
    )
}
