package com.spotpulseai.ui
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val CryptoDarkColorScheme = darkColorScheme(
    background = Color(0xFF0B0E11),
    surface = Color(0xFF181A20),
    onBackground = Color.White,
    onSurface = Color.White,
    primary = Color(0xFF2463EB),
    onPrimary = Color.White,
    error = Color(0xFFF6465D),
    secondary = Color(0xFF0ECB81) // Green
)

@Composable
fun SpotPulseTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = CryptoDarkColorScheme,
        content = content
    )
}
