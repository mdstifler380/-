package com.spotpulseai.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.platform.LocalContext
import com.spotpulseai.domain.EngineState

@Composable
fun MainAppContainer(viewModel: MainViewModel) {
    var selectedTab by remember { mutableStateOf(0) }
    val showDialog by viewModel.showApiKeyDialog.collectAsState()

    if (showDialog) {
        ApiKeySetupDialog(viewModel)
    }

    Scaffold(
        modifier = Modifier.fillMaxSize().statusBarsPadding(),
        bottomBar = {
            NavigationBar(
                containerColor = Color(0xFF080A0E),
                tonalElevation = 0.dp,
                modifier = Modifier.border(1.dp, Color(0xFF131924))
            ) {
                NavigationBarItem(
                    icon = { Text("❖", fontSize = 18.sp, color = if (selectedTab == 0) Color(0xFF2463EB) else Color.Gray) },
                    label = { Text("Dashboard", fontSize = 11.sp, color = if (selectedTab == 0) Color(0xFF2463EB) else Color.Gray) },
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    colors = NavigationBarItemDefaults.colors(indicatorColor = Color.Transparent)
                )
                NavigationBarItem(
                    icon = { Text("≡", fontSize = 18.sp, color = if (selectedTab == 1) Color(0xFF2463EB) else Color.Gray) },
                    label = { Text("Logs", fontSize = 11.sp, color = if (selectedTab == 1) Color(0xFF2463EB) else Color.Gray) },
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    colors = NavigationBarItemDefaults.colors(indicatorColor = Color.Transparent)
                )
                NavigationBarItem(
                    icon = { Text("◫", fontSize = 18.sp, color = if (selectedTab == 2) Color(0xFF2463EB) else Color.Gray) },
                    label = { Text("Ledger", fontSize = 11.sp, color = if (selectedTab == 2) Color(0xFF2463EB) else Color.Gray) },
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    colors = NavigationBarItemDefaults.colors(indicatorColor = Color.Transparent)
                )
                NavigationBarItem(
                    icon = { Text("⚙", fontSize = 18.sp, color = if (selectedTab == 3) Color(0xFF2463EB) else Color.Gray) },
                    label = { Text("Settings", fontSize = 11.sp, color = if (selectedTab == 3) Color(0xFF2463EB) else Color.Gray) },
                    selected = selectedTab == 3,
                    onClick = { selectedTab = 3 },
                    colors = NavigationBarItemDefaults.colors(indicatorColor = Color.Transparent)
                )
            }
        },
        containerColor = Color(0xFF080A0E)
    ) { paddingValues ->
        Box(modifier = Modifier.padding(paddingValues)) {
            when (selectedTab) {
                0 -> DashboardScreen(viewModel)
                1 -> LiveLogsScreen(viewModel)
                2 -> LedgerScreen()
                3 -> SystemConfigScreen(viewModel)
            }
        }
    }
}

// SCREEN 1: DASHBOARD
@Composable
fun DashboardScreen(viewModel: MainViewModel) {
    val engineState by viewModel.engineState.collectAsState()
    val walletBalance by viewModel.walletBalance.collectAsState()
    val activePos by viewModel.activePosition.collectAsState()
    val scannerRows by viewModel.scannerStates.collectAsState()
    val isLive by viewModel.isLiveMode.collectAsState()
    val isRunning = engineState == EngineState.Running

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF080A0E))
            .padding(16.dp)
    ) {
        // App Header
        Row(
            modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "SpotPulseAI",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
            IconButton(onClick = { viewModel.showApiKeyDialog.value = true }) {
                Text(text = "⚙", color = Color.Gray, fontSize = 20.sp)
            }
        }

        // Status Pills
        Row(modifier = Modifier.padding(bottom = 14.dp)) {
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(4.dp))
                    .background(Color(0xFF0ECB81).copy(alpha = 0.2f))
                    .border(1.dp, Color(0xFF0ECB81), RoundedCornerShape(4.dp))
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Text(
                    text = if (isRunning) "● ACTIVE (RUNNING)" else "○ ACTIVE (IDLE)",
                    color = Color(0xFF0ECB81),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }
            Spacer(modifier = Modifier.width(8.dp))
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(4.dp))
                    .background(Color(0xFF2463EB).copy(alpha = 0.2f))
                    .border(1.dp, Color(0xFF2463EB), RoundedCornerShape(4.dp))
                    .clickable { viewModel.showApiKeyDialog.value = true }
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Text(
                    text = if (isLive) "⚡ BINANCE (LIVE)" else "⚡ BINANCE Connected",
                    color = Color(0xFF60A5FA),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        // WALLET SYNC CARD
        Text("WALLET SYNC", fontSize = 11.sp, color = Color.Gray, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(4.dp))
        Card(
            modifier = Modifier.fillMaxWidth().border(1.dp, Color(0xFF1A2230), RoundedCornerShape(10.dp)),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF10141D)),
            shape = RoundedCornerShape(10.dp)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = "$$walletBalance FDUSD",
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "Free: $$walletBalance | Locked: $0.00",
                    fontSize = 12.sp,
                    color = Color(0xFF848E9C)
                )
                Text(
                    text = "Last Synced: 2s ago",
                    fontSize = 10.sp,
                    color = Color.DarkGray
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // ACTIVE POSITION CARD
        Text("ACTIVE POSITION (1/1 MAX)", fontSize = 11.sp, color = Color.Gray, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(4.dp))
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, Color(0xFF0ECB81).copy(alpha = 0.5f), RoundedCornerShape(10.dp)),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF0C1717)),
            shape = RoundedCornerShape(10.dp)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                if (activePos != null) {
                    Text(
                        text = "${activePos!!.pair} (0% Maker)",
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF0ECB81),
                        fontSize = 14.sp
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("Entry: ${activePos!!.entryPrice}", fontSize = 12.sp, color = Color.LightGray)
                    Text("Take-Profit: ${activePos!!.strictFloor} (Strict Green Floor ✓)", fontSize = 12.sp, color = Color(0xFF0ECB81))
                    Spacer(modifier = Modifier.height(4.dp))
                    val elapsedSec = ((System.currentTimeMillis() - activePos!!.openedAt) / 1000).coerceAtLeast(0)
                    Text("Elapsed: ${elapsedSec}s / 150s", fontSize = 11.sp, color = Color.Gray)
                } else {
                    Text("No Open Position (1/1 Available)", color = Color.Gray, fontSize = 12.sp)
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // SCANNER (ELITE 8) CARD
        Text("SCANNER (ELITE 8)", fontSize = 11.sp, color = Color.Gray, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(4.dp))
        Card(
            modifier = Modifier.fillMaxWidth().border(1.dp, Color(0xFF1A2230), RoundedCornerShape(10.dp)),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF10141D)),
            shape = RoundedCornerShape(10.dp)
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Pair", fontSize = 11.sp, color = Color.Gray, modifier = Modifier.weight(1.2f))
                    Text("Spread (bps)", fontSize = 11.sp, color = Color.Gray, modifier = Modifier.weight(1f))
                    Text("OBI", fontSize = 11.sp, color = Color.Gray, modifier = Modifier.weight(1f))
                    Text("Status", fontSize = 11.sp, color = Color.Gray, modifier = Modifier.weight(1f))
                }
                Spacer(modifier = Modifier.height(6.dp))
                
                val displayList = listOf("BTCFDUSD", "ETHFDUSD", "SUIFDUSD")
                for (sym in displayList) {
                    val row = scannerRows[sym]
                    if (row != null) {
                        ScannerRow(row.symbol, row.spread, row.obi, row.status, if (row.isMatched) Color(0xFFF6465D) else Color(0xFF0ECB81))
                    } else {
                        ScannerRow(sym, "1.5 bps", "+0.14 OBI", "STABLE", Color(0xFF0ECB81))
                    }
                }
            }
        }

        Spacer(modifier = Modifier.weight(1f))

        // Big Action Button
        val context = LocalContext.current
        Button(
            onClick = { viewModel.toggleEngine(context) },
            modifier = Modifier.fillMaxWidth().height(52.dp),
            colors = ButtonDefaults.buttonColors(containerColor = if (isRunning) Color(0xFFF6465D) else Color(0xFF0ECB81)),
            shape = RoundedCornerShape(8.dp)
        ) {
            Text(
                if (isRunning) "STOP ENGINE" else "START ENGINE",
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
        }
    }
}

@Composable
fun ScannerRow(pair: String, spread: String, obi: String, status: String, statusColor: Color) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(pair, fontSize = 12.sp, color = Color.White, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1.2f))
        Text(spread, fontSize = 12.sp, color = Color.LightGray, modifier = Modifier.weight(1f))
        Text(obi, fontSize = 12.sp, color = Color(0xFF0ECB81), modifier = Modifier.weight(1f))
        Text(status, fontSize = 11.sp, color = statusColor, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
    }
}

// SCREEN 2: REAL-TIME ACTIVITY (LIVE LOGS)
@Composable
fun LiveLogsScreen(viewModel: MainViewModel) {
    val engineState by viewModel.engineState.collectAsState()
    val logs by viewModel.liveLogs.collectAsState()
    var selectedFilter by remember { mutableStateOf("Activity Logs") }
    val isRunning = engineState == EngineState.Running

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF080A0E))
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
            horizontalArrangement = Arrangement.Center
        ) {
            Text("Live Logs", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color.White)
        }

        Row(
            modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FilterChip("Activity Logs", selectedFilter == "Activity Logs") { selectedFilter = "Activity Logs" }
            FilterChip("INFO", selectedFilter == "INFO") { selectedFilter = "INFO" }
            FilterChip("WARN", selectedFilter == "WARN") { selectedFilter = "WARN" }
            FilterChip("TRADE", selectedFilter == "TRADE") { selectedFilter = "TRADE" }
        }

        Spacer(modifier = Modifier.height(10.dp))

        Card(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .border(1.dp, Color(0xFF0ECB81).copy(alpha = 0.3f), RoundedCornerShape(10.dp)),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF06130E)),
            shape = RoundedCornerShape(10.dp)
        ) {
            val filtered = if (selectedFilter == "Activity Logs") logs else logs.filter { it.type == selectedFilter }
            LazyColumn(modifier = Modifier.padding(12.dp)) {
                items(filtered) { log ->
                    val col = when (log.type) {
                        "TRADE" -> Color(0xFF0ECB81)
                        "WARN" -> Color(0xFFFBBF24)
                        else -> Color(0xFF60A5FA)
                    }
                    LogItem(log.time, log.message, col)
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        val context = LocalContext.current
        Button(
            onClick = { viewModel.toggleEngine(context) },
            modifier = Modifier.fillMaxWidth().height(52.dp),
            colors = ButtonDefaults.buttonColors(containerColor = if (isRunning) Color(0xFFF6465D) else Color(0xFF0ECB81)),
            shape = RoundedCornerShape(8.dp)
        ) {
            Text(if (isRunning) "STOP ENGINE" else "START ENGINE", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Color.White)
        }
    }
}

@Composable
fun FilterChip(title: String, selected: Boolean, onClick: () -> Unit) {
    val borderColor = when (title) {
        "INFO" -> Color(0xFF2463EB)
        "WARN" -> Color(0xFFF59E0B)
        "TRADE" -> Color(0xFF0ECB81)
        else -> Color(0xFF2463EB)
    }
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(4.dp))
            .background(if (selected) borderColor.copy(alpha = 0.2f) else Color.Transparent)
            .border(1.dp, borderColor, RoundedCornerShape(4.dp))
            .clickable { onClick() }
            .padding(horizontal = 10.dp, vertical = 4.dp)
    ) {
        Text(title, fontSize = 11.sp, color = if (selected) Color.White else Color.Gray, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun LogItem(time: String, text: String, color: Color) {
    Row(modifier = Modifier.padding(vertical = 4.dp)) {
        Text(time, color = Color.Gray, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
        Spacer(modifier = Modifier.width(8.dp))
        Text(text, color = color, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
    }
}

// SCREEN 3: SYSTEM CONFIGURATION (ENGINE SETTINGS)
@Composable
fun SystemConfigScreen(viewModel: MainViewModel) {
    var lock1 by remember { mutableStateOf(true) }
    var interval by remember { mutableStateOf(15f) }
    val universe = remember {
        mutableStateListOf(
            "BTCFDUSD" to true, "ETHFDUSD" to true,
            "SOLFDUSD" to true, "XRPFDUSD" to true,
            "SUIFDUSD" to true, "LINKFDUSD" to true,
            "AVAXFDUSD" to true, "DOGEFDUSD" to true
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF080A0E))
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Engine Settings", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color.White)
            Text(
                "RESET TO DEFAULT",
                fontSize = 11.sp,
                color = Color.Gray,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.clickable {
                    lock1 = true
                    interval = 15f
                    for (i in universe.indices) {
                        universe[i] = universe[i].first to true
                    }
                }
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        Text("GENERAL CONFIG", fontSize = 11.sp, color = Color.Gray, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(6.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Single Position Lock (Max 1)", color = Color.White, fontSize = 13.sp)
            Switch(
                checked = lock1,
                onCheckedChange = { lock1 = it },
                colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = Color(0xFF2463EB))
            )
        }
        
        Spacer(modifier = Modifier.height(6.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("Reconcile Interval", color = Color.White, fontSize = 13.sp)
            Text("${interval.toInt()} seconds", color = Color(0xFF60A5FA), fontSize = 12.sp)
        }
        Slider(
            value = interval,
            onValueChange = { interval = it },
            valueRange = 5f..60f,
            colors = SliderDefaults.colors(thumbColor = Color(0xFF2463EB), activeTrackColor = Color(0xFF2463EB))
        )

        Spacer(modifier = Modifier.height(16.dp))

        Text("THRESHOLDS", fontSize = 11.sp, color = Color.Gray, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(6.dp))
        ThresholdItem("Max Spread Bps", "6.0 bps")
        ThresholdItem("Min OBI Buyer Pressure", "+0.08")
        ThresholdItem("Min Micro-Edge", "1.0 bp")

        Spacer(modifier = Modifier.height(16.dp))

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("ELITE 8 UNIVERSE", fontSize = 11.sp, color = Color.Gray, fontWeight = FontWeight.Bold)
            Text("All", fontSize = 11.sp, color = Color(0xFF60A5FA))
        }
        Spacer(modifier = Modifier.height(8.dp))

        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            modifier = Modifier.fillMaxWidth()
        ) {
            items(universe.size) { index ->
                val pair = universe[index]
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 4.dp)) {
                    Checkbox(
                        checked = pair.second,
                        onCheckedChange = { universe[index] = pair.first to it },
                        colors = CheckboxDefaults.colors(checkedColor = Color(0xFF2463EB), checkmarkColor = Color.White)
                    )
                    Text(pair.first, color = Color.White, fontSize = 13.sp)
                }
            }
        }
    }
}

@Composable
fun ThresholdItem(name: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(name, color = Color.White, fontSize = 13.sp)
        Text(value, color = Color(0xFF60A5FA), fontSize = 13.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun LedgerScreen() {
    Box(modifier = Modifier.fillMaxSize().background(Color(0xFF080A0E)), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("Trading Ledger / Order History", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
            Spacer(modifier = Modifier.height(6.dp))
            Text("Real Fills Only • 0.0000 FDUSD Fees", color = Color.Gray, fontSize = 12.sp)
        }
    }
}

// DIALOG: API KEYS & MODE SELECTION
@Composable
fun ApiKeySetupDialog(viewModel: MainViewModel) {
    var apiKey by remember { mutableStateOf(viewModel.sessionManager.apiKey) }
    var apiSecret by remember { mutableStateOf(viewModel.sessionManager.apiSecret) }

    Dialog(onDismissRequest = { viewModel.showApiKeyDialog.value = false }) {
        Card(
            modifier = Modifier.fillMaxWidth().border(1.dp, Color(0xFF2463EB), RoundedCornerShape(12.dp)),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF10141D)),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text("Binance API & Trading Mode", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Color.White)
                Spacer(Modifier.height(16.dp))
                
                OutlinedTextField(
                    value = apiKey, onValueChange = { apiKey = it }, 
                    label = { Text("API Key", color = Color.Gray) }, 
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Color(0xFF2463EB),
                        unfocusedBorderColor = Color.DarkGray,
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White
                    )
                )
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(
                    value = apiSecret, onValueChange = { apiSecret = it }, 
                    label = { Text("Secret Key", color = Color.Gray) }, 
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Color(0xFF2463EB),
                        unfocusedBorderColor = Color.DarkGray,
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White
                    )
                )
                Spacer(Modifier.height(20.dp))
                
                Button(
                    onClick = { viewModel.setApiKeys(apiKey, apiSecret, isLive = false) }, 
                    modifier = Modifier.fillMaxWidth().height(46.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2463EB)),
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Text("USE PAPER MODE ($42.50 Virtual)", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
                
                Spacer(Modifier.height(8.dp))
                
                Button(
                    onClick = { viewModel.setApiKeys(apiKey, apiSecret, isLive = true) }, 
                    modifier = Modifier.fillMaxWidth().height(46.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFF6465D)),
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Text("USE LIVE MODE (Real Binance Wallet)", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
            }
        }
    }
}
