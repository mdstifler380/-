package com.spotpulseai.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.spotpulseai.domain.EngineState

@Composable
fun MainAppContainer(viewModel: MainViewModel) {
    var selectedTab by remember { mutableStateOf(0) }
    
    Scaffold(
        bottomBar = {
            NavigationBar(
                containerColor = Color(0xFF080A0E),
                tonalElevation = 0.dp,
                modifier = Modifier.border(1.dp, Color(0xFF131924))
            ) {
                NavigationBarItem(
                    icon = { Text("❖", fontSize = 18.sp, color = if(selectedTab == 0) Color(0xFF2463EB) else Color.Gray) },
                    label = { Text("Dashboard", fontSize = 11.sp) },
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    colors = NavigationBarItemDefaults.colors(indicatorColor = Color.Transparent)
                )
                NavigationBarItem(
                    icon = { Text("≡", fontSize = 18.sp, color = if(selectedTab == 1) Color(0xFF2463EB) else Color.Gray) },
                    label = { Text("Logs", fontSize = 11.sp) },
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    colors = NavigationBarItemDefaults.colors(indicatorColor = Color.Transparent)
                )
                NavigationBarItem(
                    icon = { Text("◫", fontSize = 18.sp, color = if(selectedTab == 2) Color(0xFF2463EB) else Color.Gray) },
                    label = { Text("Ledger", fontSize = 11.sp) },
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    colors = NavigationBarItemDefaults.colors(indicatorColor = Color.Transparent)
                )
                NavigationBarItem(
                    icon = { Text("⚙", fontSize = 18.sp, color = if(selectedTab == 3) Color(0xFF2463EB) else Color.Gray) },
                    label = { Text("Settings", fontSize = 11.sp) },
                    selected = selectedTab == 3,
                    onClick = { selectedTab = 3 },
                    colors = NavigationBarItemDefaults.colors(indicatorColor = Color.Transparent)
                )
            }
        },
        containerColor = Color(0xFF080A0E)
    ) { paddingValues ->
        Box(modifier = Modifier.padding(paddingValues)) {
            when (selectedTab) {
                0 -> DashboardMockupScreen(viewModel)
                1 -> LiveLogsMockupScreen(viewModel)
                2 -> LedgerPlaceholderScreen()
                3 -> SystemConfigMockupScreen(viewModel)
            }
        }
    }
}

// SCREEN 1: DASHBOARD
@Composable
fun DashboardMockupScreen(viewModel: MainViewModel) {
    val engineState by viewModel.engineState.collectAsState()
    val walletBalance by viewModel.walletBalance.collectAsState()
    val isRunning = engineState == EngineState.Running

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF080A0E))
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "SpotPulseAI",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
            Text(text = "⚙", color = Color.Gray, fontSize = 20.sp)
        }

        Row(modifier = Modifier.padding(bottom = 16.dp)) {
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(4.dp))
                    .background(if (isRunning) Color(0xFF0ECB81).copy(alpha = 0.2f) else Color.DarkGray)
                    .border(1.dp, if (isRunning) Color(0xFF0ECB81) else Color.Gray, RoundedCornerShape(4.dp))
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Text(
                    text = if (isRunning) "[•] ACTIVE (RUNNING)" else "[•] STOPPED",
                    color = if (isRunning) Color(0xFF0ECB81) else Color.LightGray,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }
            Spacer(modifier = Modifier.width(8.dp))
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(4.dp))
                    .background(Color(0xFF2463EB).copy(alpha = 0.2f))
                    .border(1.dp, Color(0xFF2463EB), RoundedCornerShape(4.dp))
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Text(
                    text = "⚡ BINANCE Connected",
                    color = Color(0xFF60A5FA),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        Text("WALLET SYNC", fontSize = 11.sp, color = Color.Gray, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(4.dp))
        Card(
            modifier = Modifier.fillMaxWidth().border(1.dp, Color(0xFF1A2230), RoundedCornerShape(10.dp)),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF10141D)),
            shape = RoundedCornerShape(10.dp)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = "$$walletBalance FDUSD",
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "Free: $$walletBalance | Locked: $0.00",
                    fontSize = 12.sp,
                    color = Color(0xFF848E9C)
                )
                Text(
                    text = "Last Synced: 2s ago",
                    fontSize = 10.sp,
                    color = Color.DarkGray
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        Text("ACTIVE POSITION (1/1 MAX)", fontSize = 11.sp, color = Color.Gray, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(4.dp))
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, Color(0xFF0ECB81).copy(alpha = 0.5f), RoundedCornerShape(10.dp)),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF0C1717)),
            shape = RoundedCornerShape(10.dp)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = "SUI / FDUSD (0% Maker)",
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF0ECB81),
                    fontSize = 14.sp
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text("Entry: 1.8340", fontSize = 12.sp, color = Color.LightGray)
                Text("Take-Profit: 1.8342 (Strict Green Floor ✓)", fontSize = 12.sp, color = Color(0xFF0ECB81))
                Spacer(modifier = Modifier.height(4.dp))
                Text("Elapsed: 72s / 150s", fontSize = 11.sp, color = Color.Gray)
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        Text("SCANNER (ELITE 8)", fontSize = 11.sp, color = Color.Gray, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(4.dp))
        Card(
            modifier = Modifier.fillMaxWidth().border(1.dp, Color(0xFF1A2230), RoundedCornerShape(10.dp)),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF10141D)),
            shape = RoundedCornerShape(10.dp)
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Pair", fontSize = 11.sp, color = Color.Gray, modifier = Modifier.weight(1.2f))
                    Text("Spread (bps)", fontSize = 11.sp, color = Color.Gray, modifier = Modifier.weight(1f))
                    Text("OBI", fontSize = 11.sp, color = Color.Gray, modifier = Modifier.weight(1f))
                    Text("Status", fontSize = 11.sp, color = Color.Gray, modifier = Modifier.weight(1f))
                }
                Spacer(modifier = Modifier.height(6.dp))
                ScannerRow("BTCFDUSD", "4.2 bps", "+0.15 OBI", "STABLE", Color(0xFF0ECB81))
                ScannerRow("ETHFDUSD", "3.1 bps", "+0.11 OBI", "STABLE", Color(0xFF0ECB81))
                ScannerRow("SUIFDUSD", "1.5 bps", "+0.14 OBI", "MATCHED 🔥", Color(0xFFF6465D))
            }
        }

        Spacer(modifier = Modifier.weight(1f))

        Button(
            onClick = { viewModel.toggleEngine() },
            modifier = Modifier.fillMaxWidth().height(52.dp),
            colors = ButtonDefaults.buttonColors(containerColor = if (isRunning) Color(0xFFF6465D) else Color(0xFF0ECB81)),
            shape = RoundedCornerShape(8.dp)
        ) {
            Text(
                if (isRunning) "STOP ENGINE" else "START ENGINE",
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
        }
    }
}

@Composable
fun ScannerRow(pair: String, spread: String, obi: String, status: String, statusColor: Color) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(pair, fontSize = 12.sp, color = Color.White, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1.2f))
        Text(spread, fontSize = 12.sp, color = Color.LightGray, modifier = Modifier.weight(1f))
        Text(obi, fontSize = 12.sp, color = Color(0xFF0ECB81), modifier = Modifier.weight(1f))
        Text(status, fontSize = 11.sp, color = statusColor, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
    }
}

// SCREEN 2: REAL-TIME ACTIVITY (LIVE LOGS)
@Composable
fun LiveLogsMockupScreen(viewModel: MainViewModel) {
    val engineState by viewModel.engineState.collectAsState()
    val isRunning = engineState == EngineState.Running

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF080A0E))
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
            horizontalArrangement = Arrangement.Center
        ) {
            Text("Live Logs", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color.White)
        }

        Row(
            modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Chip("Activity Logs", true)
            Chip("INFO", false)
            Chip("WARN", false)
            Chip("TRADE", false)
        }

        Spacer(modifier = Modifier.height(10.dp))

        Card(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .border(1.dp, Color(0xFF0ECB81).copy(alpha = 0.3f), RoundedCornerShape(10.dp)),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF06130E)),
            shape = RoundedCornerShape(10.dp)
        ) {
            LazyColumn(modifier = Modifier.padding(12.dp)) {
                item { LogItem("12:14:02", "🟢 Wallet sync: $42.50 FDUSD (0.00 Locked)", Color(0xFF0ECB81)) }
                item { LogItem("12:14:08", "🔵 OBI Imbalance SUIFDUSD (+0.14, Spread 1.2bps)", Color(0xFF60A5FA)) }
                item { LogItem("12:14:09", "📄 LIMIT_MAKER BUY SUIFDUSD Qty: 23.1 @ 1.8340", Color.White) }
                item { LogItem("12:14:12", "🎯 ORDER FILLED: BUY 23.1 SUI @ 1.8340", Color(0xFF0ECB81)) }
                item { LogItem("12:14:13", "🚀 Placed LIMIT_MAKER SELL TP @ 1.8342", Color(0xFFE2E8F0)) }
                item { LogItem("12:14:50", "⏳ TP resting. Elapsed: 37s (No-Loss Exit Active)", Color(0xFFFBBF24)) }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        Button(
            onClick = { viewModel.toggleEngine() },
            modifier = Modifier.fillMaxWidth().height(52.dp),
            colors = ButtonDefaults.buttonColors(containerColor = if (isRunning) Color(0xFFF6465D) else Color(0xFF0ECB81)),
            shape = RoundedCornerShape(8.dp)
        ) {
            Text(if (isRunning) "STOP ENGINE" else "START ENGINE", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Color.White)
        }
    }
}

@Composable
fun Chip(title: String, selected: Boolean) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(4.dp))
            .background(if (selected) Color(0xFF10141D) else Color.Transparent)
            .border(1.dp, if (selected) Color(0xFF2463EB) else Color(0xFF1E2838), RoundedCornerShape(4.dp))
            .padding(horizontal = 8.dp, vertical = 4.dp)
    ) {
        Text(title, fontSize = 11.sp, color = if (selected) Color(0xFF60A5FA) else Color.Gray, fontWeight = FontWeight.Medium)
    }
}

@Composable
fun LogItem(time: String, text: String, color: Color) {
    Row(modifier = Modifier.padding(vertical = 4.dp)) {
        Text(time, color = Color.Gray, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
        Spacer(modifier = Modifier.width(8.dp))
        Text(text, color = color, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
    }
}

// SCREEN 3: SYSTEM CONFIGURATION (ENGINE SETTINGS)
@Composable
fun SystemConfigMockupScreen(viewModel: MainViewModel) {
    var lock1 by remember { mutableStateOf(true) }
    var interval by remember { mutableStateOf(15f) }
    val universe = remember {
        mutableStateListOf(
            "BTCFDUSD" to true, "ETHFDUSD" to true,
            "SOLFDUSD" to true, "XRPFDUSD" to true,
            "SUIFDUSD" to true, "LINKFDUSD" to true,
            "AVAXFDUSD" to true, "DOGEFDUSD" to true
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF080A0E))
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Engine Settings", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color.White)
            Text("RESET TO DEFAULT", fontSize = 11.sp, color = Color.Gray, fontWeight = FontWeight.Bold)
        }

        Spacer(modifier = Modifier.height(12.dp))

        Text("GENERAL CONFIG", fontSize = 11.sp, color = Color.Gray, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(6.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Single Position Lock (Max 1)", color = Color.White, fontSize = 13.sp)
            Switch(
                checked = lock1,
                onCheckedChange = { lock1 = it },
                colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = Color(0xFF2463EB))
            )
        }
        
        Spacer(modifier = Modifier.height(6.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("Reconcile Interval", color = Color.White, fontSize = 13.sp)
            Text("${interval.toInt()} seconds", color = Color(0xFF60A5FA), fontSize = 12.sp)
        }
        Slider(
            value = interval,
            onValueChange = { interval = it },
            valueRange = 5f..60f,
            colors = SliderDefaults.colors(thumbColor = Color(0xFF2463EB), activeTrackColor = Color(0xFF2463EB))
        )

        Spacer(modifier = Modifier.height(16.dp))

        Text("THRESHOLDS", fontSize = 11.sp, color = Color.Gray, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(6.dp))
        ThresholdItem("Max Spread Bps", "6.0 bps")
        ThresholdItem("Min OBI Buyer Pressure", "+0.08")
        ThresholdItem("Min Micro-Edge", "1.0 bp")

        Spacer(modifier = Modifier.height(16.dp))

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("ELITE 8 UNIVERSE", fontSize = 11.sp, color = Color.Gray, fontWeight = FontWeight.Bold)
            Text("All", fontSize = 11.sp, color = Color(0xFF60A5FA))
        }
        Spacer(modifier = Modifier.height(8.dp))

        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            modifier = Modifier.fillMaxWidth()
        ) {
            items(universe.size) { index ->
                val pair = universe[index]
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 4.dp)) {
                    Checkbox(
                        checked = pair.second,
                        onCheckedChange = { universe[index] = pair.first to it },
                        colors = CheckboxDefaults.colors(checkedColor = Color(0xFF2463EB), checkmarkColor = Color.White)
                    )
                    Text(pair.first, color = Color.White, fontSize = 13.sp)
                }
            }
        }
    }
}

@Composable
fun ThresholdItem(name: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(name, color = Color.White, fontSize = 13.sp)
        Text(value, color = Color(0xFF60A5FA), fontSize = 13.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun LedgerPlaceholderScreen() {
    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Text("Trading Ledger / Order History", color = Color.Gray)
    }
}
