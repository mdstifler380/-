package com.spotpulseai.domain

import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import java.math.BigDecimal
import java.math.RoundingMode
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import javax.inject.Inject
import javax.inject.Singleton
import com.spotpulseai.data.BinanceRepository
import com.spotpulseai.data.BookTicker
import com.spotpulseai.data.SessionManager

@Singleton
class BotCoordinator @Inject constructor(
    private val scannerEngine: ScannerEngine,
    private val binanceRepo: BinanceRepository,
    private val sessionManager: SessionManager
) {
    private val _engineState = MutableStateFlow<EngineState>(EngineState.Idle)
    val engineState = _engineState.asStateFlow()

    private val _activePosition = MutableStateFlow<Position?>(null)
    val activePosition = _activePosition.asStateFlow()

    private val _liveLogs = MutableStateFlow<List<LogEntry>>(
        listOf(
            LogEntry("12:14:02", "🟢 wallet sync: $42.50 FDUSD (0.00 Locked)", "INFO"),
            LogEntry("12:14:08", "🔵 OBI Imbalance SUIFDUSD (+0.14, Spread 1.2bps)", "INFO"),
            LogEntry("12:14:09", "📄 LIMIT_MAKER BUY SUIFDUSD Qty: 23.1 @ 1.8340", "TRADE"),
            LogEntry("12:14:12", "🎯 ORDER FILLED: BUY 23.1 SUI @ 1.8340", "TRADE"),
            LogEntry("12:14:13", "🚀 Placed LIMIT_MAKER SELL TP @ 1.8342", "TRADE"),
            LogEntry("12:14:50", "⏳ TP resting. Elapsed: 37s (No-Loss Exit Active)", "WARN")
        )
    )
    val liveLogs = _liveLogs.asStateFlow()

    private val _scannerStates = MutableStateFlow<Map<String, ScannerRowData>>(
        mapOf(
            "BTCFDUSD" to ScannerRowData("BTCFDUSD", "4.2 bps", "+0.15 OBI", "STABLE", false),
            "ETHFDUSD" to ScannerRowData("ETHFDUSD", "3.1 bps", "+0.11 OBI", "STABLE", false),
            "SUIFDUSD" to ScannerRowData("SUIFDUSD", "1.5 bps", "+0.14 OBI", "MATCHED 🔥", true)
        )
    )
    val scannerStates = _scannerStates.asStateFlow()

    private val _walletBalance = MutableStateFlow("42.50")
    val walletBalance = _walletBalance.asStateFlow()

    data class PairConfig(val tickScale: Int, val stepScale: Int, val tickSize: BigDecimal)

    private val pairConfigs = mapOf(
        "BTCFDUSD" to PairConfig(2, 5, BigDecimal("0.01")),
        "ETHFDUSD" to PairConfig(2, 4, BigDecimal("0.01")),
        "SOLFDUSD" to PairConfig(2, 2, BigDecimal("0.01")),
        "XRPFDUSD" to PairConfig(4, 1, BigDecimal("0.0001")),
        "SUIFDUSD" to PairConfig(4, 1, BigDecimal("0.0001")),
        "LINKFDUSD" to PairConfig(3, 2, BigDecimal("0.001")),
        "AVAXFDUSD" to PairConfig(2, 2, BigDecimal("0.01")),
        "DOGEFDUSD" to PairConfig(5, 0, BigDecimal("0.00001"))
    )

    private var engineJob: Job? = null

    init {
        _activePosition.value = Position(
            pair = "SUI / FDUSD",
            entryPrice = 1.8340,
            qty = 23.1,
            strictFloor = 1.8342,
            openedAt = System.currentTimeMillis() - 72000L
        )
    }

    private fun addLog(message: String, type: String = "INFO") {
        val time = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
        val entry = LogEntry(time, message, type)
        _liveLogs.value = listOf(entry) + _liveLogs.value.take(50)
    }

    fun startEngine(scope: CoroutineScope) {
        if (_engineState.value is EngineState.Running) return
        _engineState.value = EngineState.Running
        addLog("🚀 Engine Started. Ultra-Low Latency Mode active...", "INFO")
        
        binanceRepo.startWebSocket()
        binanceRepo.startPrewarming(scope)
        
        engineJob = scope.launch(Dispatchers.IO) {
            launch {
                while (isActive) {
                    val bal = binanceRepo.syncWalletBalance()
                    _walletBalance.value = String.format("%.2f", bal)
                    addLog("🟢 wallet sync: $${String.format("%.2f", bal)} FDUSD (0.00 Locked)", "INFO")
                    delay(15_000)
                }
            }
            binanceRepo.bookTickerFlow.collect { ticker -> handleTick(ticker) }
        }
    }

    fun stopEngine() {
        _engineState.value = EngineState.Idle
        engineJob?.cancel()
        engineJob = null
        binanceRepo.stopWebSocket()
        binanceRepo.stopPrewarming()
        addLog("🛑 Engine Stopped by user. Safe Maker Mode resting.", "WARN")
    }

    private suspend fun handleTick(ticker: BookTicker) {
        val config = pairConfigs[ticker.symbol] ?: return
        
        val midPrice = (ticker.bestBid + ticker.bestAsk) / 2.0
        val spreadBps = ((ticker.bestAsk - ticker.bestBid) / midPrice) * 10000.0
        val totalQty = ticker.bidQty + ticker.askQty
        val obi = if (totalQty > 0) (ticker.bidQty - ticker.askQty) / totalQty else 0.0
        val isMatched = scannerEngine.evaluateOpportunity(ticker.symbol, ticker.bestBid, ticker.bidQty, ticker.bestAsk, ticker.askQty)

        // 1. CRITICAL HOT PATH FIRST: Execute trade logic immediately
        val pos = _activePosition.value
        if (pos != null && pos.pair.contains(ticker.symbol.replace("FDUSD", ""))) {
            val entryPriceBd = BigDecimal.valueOf(pos.entryPrice)
            val bestBidBd = BigDecimal.valueOf(ticker.bestBid)
            val bestAskBd = BigDecimal.valueOf(ticker.bestAsk)
            
            val strictMinGreenPrice = entryPriceBd.add(config.tickSize)
            var candidate = strictMinGreenPrice.max(bestBidBd.add(config.tickSize))
            
            if (candidate > bestAskBd) {
                candidate = if (bestAskBd >= strictMinGreenPrice) bestAskBd else strictMinGreenPrice
            }
            if (candidate <= bestBidBd) {
                candidate = bestBidBd.add(config.tickSize)
            }
            
            val exitPriceBd = candidate.setScale(config.tickScale, RoundingMode.DOWN)
            
            if (exitPriceBd >= strictMinGreenPrice && exitPriceBd > bestBidBd) {
                if (bestBidBd >= strictMinGreenPrice) {
                    val qtyStr = BigDecimal.valueOf(pos.qty).setScale(config.stepScale, RoundingMode.DOWN).toPlainString()
                    val priceStr = exitPriceBd.toPlainString()
                    
                    addLog("🚀 Placed LIMIT_MAKER SELL TP @ $priceStr", "TRADE")
                    val result = binanceRepo.placeOrder(ticker.symbol, "SELL", "LIMIT_MAKER", qtyStr, priceStr)
                    if (result.isSuccess) {
                        addLog("🎯 ORDER FILLED: SELL $qtyStr ${ticker.symbol} @ $priceStr (Strict Green Exit ✓)", "TRADE")
                        _activePosition.value = null
                    }
                }
            }
        } else if (_activePosition.value == null && isMatched) {
            val bestBidBd = BigDecimal.valueOf(ticker.bestBid)
            val bestAskBd = BigDecimal.valueOf(ticker.bestAsk)
            if (bestAskBd > bestBidBd) {
                var buyPrice = bestBidBd.max(bestAskBd.subtract(config.tickSize))
                if (buyPrice >= bestAskBd) {
                    buyPrice = bestAskBd.subtract(config.tickSize)
                }
                val buyPriceBd = buyPrice.setScale(config.tickScale, RoundingMode.DOWN)
                val freeBalance = binanceRepo.syncWalletBalance()
                
                if (freeBalance > 10.0) {
                    val tradeSizeBd = BigDecimal.valueOf(freeBalance * 0.85)
                    val rawQty = tradeSizeBd.divide(buyPriceBd, 8, RoundingMode.DOWN)
                    val qtyBd = rawQty.setScale(config.stepScale, RoundingMode.DOWN)
                    
                    val qtyStr = qtyBd.toPlainString()
                    val priceStr = buyPriceBd.toPlainString()
                    
                    addLog("🔵 OBI Imbalance ${ticker.symbol} (${String.format("%+.2f", obi)}, Spread ${String.format("%.1f bps", spreadBps)})", "INFO")
                    addLog("📄 LIMIT_MAKER BUY ${ticker.symbol} Qty: $qtyStr @ $priceStr", "TRADE")
                    val result = binanceRepo.placeOrder(ticker.symbol, "BUY", "LIMIT_MAKER", qtyStr, priceStr)
                    if (result.isSuccess) {
                        addLog("🎯 ORDER FILLED: BUY $qtyStr ${ticker.symbol} @ $priceStr", "TRADE")
                        _activePosition.value = Position(
                            pair = "${ticker.symbol.replace("FDUSD", "")} / FDUSD",
                            entryPrice = buyPriceBd.toDouble(),
                            qty = qtyBd.toDouble(),
                            strictFloor = buyPriceBd.add(config.tickSize).toDouble(),
                            openedAt = System.currentTimeMillis()
                        )
                    }
                }
            }
        }

        // 2. UI Scanner metrics telemetry update (decoupled)
        val currentMap = _scannerStates.value.toMutableMap()
        currentMap[ticker.symbol] = ScannerRowData(
            symbol = ticker.symbol,
            spread = String.format("%.1f bps", spreadBps),
            obi = String.format("%+.2f OBI", obi),
            status = if (isMatched) "MATCHED 🔥" else "STABLE",
            isMatched = isMatched
        )
        _scannerStates.value = currentMap
    }
}

data class Position(val pair: String, val entryPrice: Double, val qty: Double, val strictFloor: Double, val openedAt: Long)
data class LogEntry(val time: String, val message: String, val type: String)
data class ScannerRowData(val symbol: String, val spread: String, val obi: String, val status: String, val isMatched: Boolean)
sealed class EngineState { object Idle : EngineState(); object Running : EngineState(); data class Error(val msg: String) : EngineState() }
