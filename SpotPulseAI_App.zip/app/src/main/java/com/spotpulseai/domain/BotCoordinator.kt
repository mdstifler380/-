package com.spotpulseai.domain

import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import javax.inject.Inject
import javax.inject.Singleton
import com.spotpulseai.data.BinanceRepository
import com.spotpulseai.data.BookTicker

@Singleton
class BotCoordinator @Inject constructor(
    private val scannerEngine: ScannerEngine,
    private val binanceRepo: BinanceRepository
) {
    private val _engineState = MutableStateFlow<EngineState>(EngineState.Idle)
    val engineState = _engineState.asStateFlow()
    private var currentPosition: Position? = null
    
    private val tickSizeMap = mapOf(
        "BTCFDUSD" to 0.01, "ETHFDUSD" to 0.01, "SOLFDUSD" to 0.01, 
        "XRPFDUSD" to 0.0001, "SUIFDUSD" to 0.0001, "LINKFDUSD" to 0.001, 
        "AVAXFDUSD" to 0.01, "DOGEFDUSD" to 0.00001
    )

    private var engineJob: Job? = null

    fun startEngine(scope: CoroutineScope) {
        if (_engineState.value is EngineState.Running) return
        _engineState.value = EngineState.Running
        binanceRepo.startWebSocket()
        
        engineJob = scope.launch {
            launch {
                while (isActive) {
                    binanceRepo.syncWalletBalance()
                    delay(15_000)
                }
            }
            binanceRepo.bookTickerFlow.collect { ticker -> handleTick(ticker) }
        }
    }

    fun stopEngine() {
        _engineState.value = EngineState.Idle
        engineJob?.cancel()
        binanceRepo.stopWebSocket()
        currentPosition = null
    }

    private suspend fun handleTick(ticker: BookTicker) {
        val pos = currentPosition
        if (pos != null && pos.pair == ticker.symbol) {
            val tickSize = tickSizeMap[pos.pair] ?: 0.01
            val strictMinGreenPrice = pos.entryPrice + tickSize
            if (ticker.bestBid >= strictMinGreenPrice) {
                binanceRepo.placeOrder(pos.pair, "SELL", "LIMIT_MAKER", pos.qty, ticker.bestBid)
                currentPosition = null
            }
            return
        }
        if (currentPosition == null) {
            val isOpportunity = scannerEngine.evaluateOpportunity(ticker.symbol, ticker.bestBid, ticker.bidQty, ticker.bestAsk, ticker.askQty)
            if (isOpportunity) {
                val freeBalance = binanceRepo.syncWalletBalance()
                if (freeBalance > 10.0) { 
                    val tradeSize = freeBalance * 0.85
                    val qty = tradeSize / ticker.bestBid
                    val result = binanceRepo.placeOrder(ticker.symbol, "BUY", "LIMIT_MAKER", qty, ticker.bestBid)
                    if (result.isSuccess) {
                        currentPosition = Position(ticker.symbol, ticker.bestBid, qty)
                    }
                }
            }
        }
    }
}

data class Position(val pair: String, val entryPrice: Double, val qty: Double)
sealed class EngineState { object Idle : EngineState(); object Running : EngineState(); data class Error(val msg: String) : EngineState() }
