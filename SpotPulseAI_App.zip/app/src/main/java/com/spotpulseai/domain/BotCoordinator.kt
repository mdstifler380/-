package com.spotpulseai.domain

import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import javax.inject.Inject
import javax.inject.Singleton
import com.spotpulseai.data.BinanceRepository
import com.spotpulseai.data.BookTicker
import kotlin.math.max

@Singleton
class BotCoordinator @Inject constructor(
    private val scannerEngine: ScannerEngine,
    private val binanceRepo: BinanceRepository
) {
    private val _engineState = MutableStateFlow<EngineState>(EngineState.Idle)
    val engineState = _engineState.asStateFlow()
    private var currentPosition: Position? = null
    
    private val tickSizeMap = mapOf(
        "BTCFDUSD" to 0.01, "ETHFDUSD" to 0.01, "SOLFDUSD" to 0.01, 
        "XRPFDUSD" to 0.0001, "SUIFDUSD" to 0.0001, "LINKFDUSD" to 0.001, 
        "AVAXFDUSD" to 0.01, "DOGEFDUSD" to 0.00001
    )

    private var engineJob: Job? = null

    fun startEngine(scope: CoroutineScope) {
        if (_engineState.value is EngineState.Running) return
        _engineState.value = EngineState.Running
        binanceRepo.startWebSocket()
        
        engineJob = scope.launch {
            launch {
                while (isActive) {
                    binanceRepo.syncWalletBalance()
                    delay(15_000)
                }
            }
            binanceRepo.bookTickerFlow.collect { ticker -> handleTick(ticker) }
        }
    }

    fun stopEngine() {
        _engineState.value = EngineState.Idle
        engineJob?.cancel()
        binanceRepo.stopWebSocket()
        // Do not clear currentPosition here to avoid losing track of the real position
    }

    private suspend fun handleTick(ticker: BookTicker) {
        val pos = currentPosition
        if (pos != null && pos.pair == ticker.symbol) {
            val tickSize = tickSizeMap[pos.pair] ?: 0.01
            val strictMinGreenPrice = pos.entryPrice + tickSize
            
            // ARCHITECTURE RULE 8: Maker-Safe Exit Price
            var candidate = max(strictMinGreenPrice, ticker.bestBid + tickSize)
            
            if (candidate > ticker.bestAsk) {
                if (ticker.bestAsk >= strictMinGreenPrice) {
                    candidate = ticker.bestAsk
                } else {
                    candidate = strictMinGreenPrice
                }
            }
            if (candidate <= ticker.bestBid) {
                candidate = ticker.bestBid + tickSize
            }
            
            val exitPrice = candidate
            
            // Only fire if the exitPrice is completely safe and won't match immediately as a taker
            if (exitPrice >= strictMinGreenPrice && exitPrice > ticker.bestBid) {
                // In a real system, you'd check if an exit order is already placed.
                // For this mock engine execution loop:
                if (ticker.bestBid >= strictMinGreenPrice) {
                     val result = binanceRepo.placeOrder(pos.pair, "SELL", "LIMIT_MAKER", pos.qty, exitPrice)
                     if (result.isSuccess) {
                         currentPosition = null
                     }
                }
            }
            return
        }
        
        if (currentPosition == null) {
            val isOpportunity = scannerEngine.evaluateOpportunity(ticker.symbol, ticker.bestBid, ticker.bidQty, ticker.bestAsk, ticker.askQty)
            if (isOpportunity) {
                // ARCHITECTURE RULE 9: Maker-Safe Entry Price
                if (ticker.bestAsk <= ticker.bestBid) return // Crossed book invalid
                
                val tickSize = tickSizeMap[ticker.symbol] ?: 0.01
                var buyPrice = max(ticker.bestBid, ticker.bestAsk - tickSize)
                if (buyPrice >= ticker.bestAsk) {
                    buyPrice = ticker.bestAsk - tickSize
                }
                
                val freeBalance = binanceRepo.syncWalletBalance()
                if (freeBalance > 10.0) { 
                    val tradeSize = freeBalance * 0.85
                    val qty = tradeSize / buyPrice
                    val result = binanceRepo.placeOrder(ticker.symbol, "BUY", "LIMIT_MAKER", qty, buyPrice)
                    if (result.isSuccess) {
                        currentPosition = Position(ticker.symbol, buyPrice, qty)
                    }
                }
            }
        }
    }
}

data class Position(val pair: String, val entryPrice: Double, val qty: Double)
sealed class EngineState { object Idle : EngineState(); object Running : EngineState(); data class Error(val msg: String) : EngineState() }
