package com.spotpulseai.domain
import javax.inject.Inject

class ScannerEngine @Inject constructor() {
    private val elitePairs = listOf("BTCFDUSD", "ETHFDUSD", "SOLFDUSD", "XRPFDUSD", "SUIFDUSD", "LINKFDUSD", "AVAXFDUSD", "DOGEFDUSD")
    fun evaluateOpportunity(pair: String, bidPrice: Double, bidQty: Double, askPrice: Double, askQty: Double): Boolean {
        if (pair !in elitePairs) return false
        val spreadBps = ((askPrice - bidPrice) / askPrice) * 10000
        if (spreadBps > 6.0) return false
        val obi = (bidQty - askQty) / (bidQty + askQty)
        if (obi < 0.08) return false
        val microEdge = spreadBps * obi
        if (microEdge < 1.0) return false
        return true
    }
}
