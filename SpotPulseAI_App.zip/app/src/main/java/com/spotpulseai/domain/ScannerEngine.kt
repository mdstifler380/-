package com.spotpulseai.domain

import javax.inject.Inject

class ScannerEngine @Inject constructor() {
    val elitePairs = listOf(
        "BTCFDUSD", "ETHFDUSD", "SOLFDUSD", "XRPFDUSD",
        "SUIFDUSD", "LINKFDUSD", "AVAXFDUSD", "DOGEFDUSD"
    )

    fun evaluateOpportunity(pair: String, bidPrice: Double, bidQty: Double, askPrice: Double, askQty: Double): Boolean {
        if (pair !in elitePairs) return false
        if (askPrice <= bidPrice) return false
        
        val midPrice = (bidPrice + askPrice) / 2.0
        val spreadBps = ((askPrice - bidPrice) / midPrice) * 10000.0
        if (spreadBps > 6.0) return false
        
        val totalQty = bidQty + askQty
        if (totalQty <= 0.0) return false
        val obi = (bidQty - askQty) / totalQty
        if (obi < 0.08) return false
        
        val microEdge = spreadBps * obi
        if (microEdge < 0.10) return false
        
        return true
    }
}
