package com.spotpulseai.data

import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicLong
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class BinanceRepository @Inject constructor(
    private val sessionManager: SessionManager
) {
    // Ultra-low latency buffer: drops stale ticks to ensure trading logic only consumes real-time data
    private val _bookTickerFlow = MutableSharedFlow<BookTicker>(
        replay = 0,
        extraBufferCapacity = 64,
        onBufferOverflow = BufferOverflow.DROP_OLDEST
    )
    val bookTickerFlow: SharedFlow<BookTicker> = _bookTickerFlow

    // Pre-allocated HTTP/2 Connection Pool for 0ms handshake overhead
    private val connectionPool = ConnectionPool(16, 5, TimeUnit.MINUTES)
    private val client = OkHttpClient.Builder()
        .connectionPool(connectionPool)
        .pingInterval(15, TimeUnit.SECONDS)
        .connectTimeout(5, TimeUnit.SECONDS)
        .readTimeout(5, TimeUnit.SECONDS)
        .writeTimeout(5, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .build()

    private var webSocket: WebSocket? = null
    private val serverTimeOffset = AtomicLong(0L)
    private var prewarmJob: kotlinx.coroutines.Job? = null

    private fun generateSignature(data: String, secret: String): String {
        val mac = Mac.getInstance("HmacSHA256")
        val secretKeySpec = SecretKeySpec(secret.toByteArray(), "HmacSHA256")
        mac.init(secretKeySpec)
        return mac.doFinal(data.toByteArray()).joinToString("") { "%02x".format(it) }
    }

    // Pre-warms the TLS 1.3 session so order placement never suffers handshake latency
    fun startPrewarming(scope: CoroutineScope) {
        if (prewarmJob != null) return
        prewarmJob = scope.launch(Dispatchers.IO) {
            syncServerTime()
            while (isActive) {
                try {
                    val request = Request.Builder()
                        .url("https://api.binance.com/api/v3/ping")
                        .get()
                        .build()
                    val resp = client.newCall(request).execute()
                    resp.close()
                } catch (_: Exception) {}
                delay(20_000)
            }
        }
    }

    fun stopPrewarming() {
        prewarmJob?.cancel()
        prewarmJob = null
    }

    suspend fun syncServerTime() = withContext(Dispatchers.IO) {
        try {
            val t0 = System.currentTimeMillis()
            val request = Request.Builder().url("https://api.binance.com/api/v3/time").get().build()
            val response = client.newCall(request).execute()
            try {
                val t1 = System.currentTimeMillis()
                if (response.isSuccessful) {
                    val json = JSONObject(response.body?.string() ?: "")
                    val serverTime = json.getLong("serverTime")
                    val rtt = t1 - t0
                    val offset = serverTime - (t0 + rtt / 2)
                    serverTimeOffset.set(offset)
                }
            } finally {
                response.close()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun startWebSocket() {
        if (webSocket != null) return
        val streams = listOf("btc", "eth", "sol", "xrp", "sui", "link", "avax", "doge")
            .joinToString("/") { "${it}fdusd@bookTicker" }
        
        val url = "wss://stream.binance.com:9443/stream?streams=$streams"
        val request = Request.Builder().url(url).build()
        webSocket = client.newWebSocket(request, object : WebSocketListener() {
            override fun onMessage(webSocket: WebSocket, text: String) {
                try {
                    val rawJson = JSONObject(text)
                    val json = if (rawJson.has("data")) rawJson.getJSONObject("data") else rawJson
                    val ticker = BookTicker(
                        symbol = json.getString("s"),
                        bestBid = json.getDouble("b"),
                        bidQty = json.getDouble("B"),
                        bestAsk = json.getDouble("a"),
                        askQty = json.getDouble("A")
                    )
                    _bookTickerFlow.tryEmit(ticker)
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                t.printStackTrace()
            }
        })
    }

    fun stopWebSocket() {
        try {
            webSocket?.close(1000, "Engine Stopped")
        } catch (_: Exception) {}
        webSocket = null
    }

    suspend fun syncWalletBalance(): Double = withContext(Dispatchers.IO) {
        if (!sessionManager.isLiveMode) return@withContext sessionManager.paperBalance
        if (sessionManager.apiKey.isEmpty() || sessionManager.apiSecret.isEmpty()) return@withContext 0.0

        try {
            val timestamp = (System.currentTimeMillis() + serverTimeOffset.get()).toString()
            val queryString = "recvWindow=5000&timestamp=$timestamp"
            val signature = generateSignature(queryString, sessionManager.apiSecret)
            
            val url = "https://api.binance.com/api/v3/account?$queryString&signature=$signature"
            val request = Request.Builder()
                .url(url)
                .addHeader("X-MBX-APIKEY", sessionManager.apiKey)
                .get()
                .build()

            val response = client.newCall(request).execute()
            try {
                if (!response.isSuccessful) return@withContext 0.0
                val json = JSONObject(response.body?.string() ?: "")
                val balances = json.getJSONArray("balances")
                for (i in 0 until balances.length()) {
                    val asset = balances.getJSONObject(i)
                    if (asset.getString("asset") == "FDUSD") {
                        return@withContext asset.getDouble("free")
                    }
                }
            } finally {
                response.close()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return@withContext 0.0
    }

    suspend fun placeOrder(symbol: String, side: String, type: String, quantity: String, price: String): OrderResult = withContext(Dispatchers.IO) {
        if (!sessionManager.isLiveMode) {
            val q = quantity.toDoubleOrNull() ?: 0.0
            val p = price.toDoubleOrNull() ?: 0.0
            val orderValue = q * p
            if (side == "BUY") sessionManager.paperBalance -= orderValue
            if (side == "SELL") sessionManager.paperBalance += orderValue
            return@withContext OrderResult(true, "FILLED", q, p)
        }

        try {
            val timestamp = (System.currentTimeMillis() + serverTimeOffset.get()).toString()
            val params = "symbol=$symbol&side=$side&type=$type&timeInForce=GTC&quantity=$quantity&price=$price&recvWindow=5000&timestamp=$timestamp"
            val signature = generateSignature(params, sessionManager.apiSecret)
            
            val url = "https://api.binance.com/api/v3/order?$params&signature=$signature"
            val requestBody = "".toRequestBody("application/x-www-form-urlencoded".toMediaType())
            
            val request = Request.Builder()
                .url(url)
                .addHeader("X-MBX-APIKEY", sessionManager.apiKey)
                .post(requestBody)
                .build()

            val response = client.newCall(request).execute()
            try {
                val responseBody = response.body?.string() ?: ""
                if (response.isSuccessful) {
                    val json = JSONObject(responseBody)
                    val q = quantity.toDoubleOrNull() ?: 0.0
                    val p = price.toDoubleOrNull() ?: 0.0
                    return@withContext OrderResult(true, json.optString("status", "NEW"), q, p)
                } else {
                    return@withContext OrderResult(false, "REJECTED: $responseBody", 0.0, 0.0)
                }
            } finally {
                response.close()
            }
        } catch (e: Exception) {
            return@withContext OrderResult(false, "ERROR: ${e.message}", 0.0, 0.0)
        }
    }
}

data class OrderResult(val isSuccess: Boolean, val status: String, val quantity: Double, val price: Double)
data class BookTicker(val symbol: String, val bestBid: Double, val bidQty: Double, val bestAsk: Double, val askQty: Double)
