package com.spotpulseai.data
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class SessionManager @Inject constructor() {
    var apiKey: String = ""
    var apiSecret: String = ""
    var isLiveMode: Boolean = false
    var paperBalance: Double = 20.00
}
