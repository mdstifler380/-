# SpotPulseAI — Algorithmic Trading Bot (vFinal Low-Latency Edition)

## Project Overview
SpotPulseAI is an Android-based algorithmic trading engine specifically designed for Binance Spot FDUSD pairs. It operates exclusively with **0% Maker fee** orders (`LIMIT_MAKER`) with strict zero-loss exit enforcement ("Strict Green Exit Floor") and hardware/network low-latency optimizations.

## Latency Optimization Architecture
- **Zero-Handshake HTTP/2 Pre-Warming:** Maintains an active HTTP/2 connection pool with periodic keep-alive pings (`/api/v3/ping`). Reuses established TLS 1.3 sessions for 0ms handshake overhead when placing orders.
- **Dynamic Clock Sync & RTT Measurement:** Periodically syncs with Binance's server time (`/api/v3/time`), computes one-way trip delay ($RTT / 2$), and adjusts local timestamps dynamically to prevent `-1021` (`outside of recvWindow`) errors.
- **Android Background TradingService & WakeLock:** Runs as an Android Foreground Service with a `PARTIAL_WAKE_LOCK`, ensuring the OS CPU and Wi-Fi/cellular radio never throttle or enter Doze mode when the screen turns off.
- **Dropping Stale Ticks (`BufferOverflow.DROP_OLDEST`):** Employs non-blocking Kotlin Coroutine `SharedFlow` with buffer overflow set to drop stale ticks, guaranteeing the trading engine evaluates decisions only on the freshest orderbook data.
- **Happy Eyeballs Routing:** Uses OkHttp's `fastFallback(true)` (RFC 8305) to race IPv4 and IPv6 routes for the lowest latency path on mobile networks.
- **Decoupled Hot-Path Processing:** Trade evaluation and order execution are triggered immediately on arrival, completely decoupling UI telemetry rendering from trade-critical decisions.

## Trading Strategy & Rules
- **Elite 8 Universe:** BTCFDUSD, ETHFDUSD, SOLFDUSD, XRPFDUSD, SUIFDUSD, LINKFDUSD, AVAXFDUSD, DOGEFDUSD.
- **Pure Maker Execution:** Never crosses the book as a taker. Fee is $0.0000 on every transaction.
- **Strict Green Exit Floor:** Exit orders are placed strictly at `avgEntryPrice + 1 tick` or higher.
- **Single Position Enforcement:** Maximum of 1 active open position at any time to preserve capital.
- **Dual Execution Modes:**
  - **Paper Mode:** Real-time Binance WebSocket market data stream with a virtual wallet.
  - **Live Mode:** Real authenticated HMAC-SHA256 signed REST API orders executed on Binance Spot.
- **Exact High-Fidelity UI:** Dark Cyber aesthetic matching the terminal mockups with real-time Dashboard, Live Monospace Logs, and System Configuration.

## How to Build via GitHub Actions
1. Upload this `.zip` file directly to your GitHub repository.
2. Ensure the `.github/workflows/build-android.yml` workflow is committed.
3. GitHub Actions will extract the project, set up JDK 17 & Gradle 8.7, and compile `app-debug.apk`.
4. Download the compiled APK from the GitHub Actions Artifacts section.

## Samsung Galaxy S25 (Android 15 / One UI 7) Optimizations
- **Zero Crash Android 15 Foreground Service:** Uses `ServiceCompat.startForeground` with explicit `FOREGROUND_SERVICE_TYPE_DATA_SYNC` to comply with strict Android 14/15 requirements.
- **Punch-Hole Camera Safe Insets:** Built with `statusBarsPadding()` so the terminal header and status badges never collide with the Galaxy S25's centered front camera cutout.
- **One UI 7 Battery Settings (Crucial):**
  1. Go to **Settings → Apps → SpotPulseAI → Battery**.
  2. Select **Unrestricted** (prevents Samsung Smart Manager from sleeping the WebSocket connection).
