# SpotPulseAI 

## Project Overview
SpotPulseAI is an Android-based algorithmic trading execution engine strictly targeting Binance Spot FDUSD pairs. 

## Features
- **Paper Mode:** Uses real-time Binance WebSocket market data, executing mock trades against a virtual $20.00.
- **Live Mode Architecture:** Contains the required layers to plug in your HMAC-SHA256 signing routines when you are ready to use real funds.
